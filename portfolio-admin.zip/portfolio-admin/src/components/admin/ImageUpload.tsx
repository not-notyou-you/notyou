import { useRef, useState, type DragEvent } from 'react'
import toast from 'react-hot-toast'
import { useImageUpload } from '@/hooks/useImageUpload'

interface ImageUploadProps {
  onUpload: (url: string) => void
  currentImage?: string | null
  label?: string
  maxSizeMB?: number
}

export function ImageUpload({ onUpload, currentImage, label = 'Image', maxSizeMB = 5 }: ImageUploadProps) {
  const { upload, uploading, progress } = useImageUpload(maxSizeMB)
  const [dragging, setDragging] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const handleFile = async (file: File | undefined) => {
    if (!file) return
    const url = await upload(file)
    if (url) {
      onUpload(url)
      toast.success('Image uploaded.')
    } else {
      toast.error('Could not upload image. Check the file and try again.')
    }
  }

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setDragging(false)
    handleFile(e.dataTransfer.files?.[0])
  }

  return (
    <div className="form-group">
      <label>
        {label}
        <span className="field-optional">optional — JPG/PNG, up to {maxSizeMB}MB</span>
      </label>
      <div
        className={`image-upload ${dragging ? 'image-upload--dragging' : ''}`}
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault()
          setDragging(true)
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
      >
        {currentImage && <img src={currentImage} alt="Current" className="image-upload__preview" />}
        <div className="image-upload__hint">
          {uploading ? `Uploading… ${progress}%` : 'Click or drop an image here'}
        </div>
        {uploading && (
          <div className="image-upload__progress">
            <div className="image-upload__progress-bar" style={{ width: `${progress}%` }} />
          </div>
        )}
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          hidden
          onChange={(e) => handleFile(e.target.files?.[0])}
        />
      </div>
    </div>
  )
}
