import { Navigate, Route, Routes } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { ThemeProvider } from '@/contexts/ThemeContext'
import { ProtectedRoute } from '@/components/admin/ProtectedRoute'
import { LoginPage } from '@/pages/admin/LoginPage'
import { ManagementIndexPage } from '@/pages/admin/ManagementIndexPage'
import { IdentityManagementPage } from '@/pages/admin/IdentityManagementPage'
import { IntellectManagementPage } from '@/pages/admin/IntellectManagementPage'
import { PassionManagementPage } from '@/pages/admin/PassionManagementPage'

export default function App() {
  return (
    <ThemeProvider>
      <Toaster position="top-right" toastOptions={{ style: { fontSize: 13 } }} />
      <Routes>
        <Route path="/" element={<Navigate to="/admin/login" replace />} />
        <Route path="/admin" element={<Navigate to="/admin/login" replace />} />
        <Route path="/admin/login" element={<LoginPage />} />
        <Route
          path="/admin/management"
          element={
            <ProtectedRoute>
              <ManagementIndexPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin/management/identity"
          element={
            <ProtectedRoute>
              <IdentityManagementPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin/management/intellect"
          element={
            <ProtectedRoute>
              <IntellectManagementPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin/management/passion"
          element={
            <ProtectedRoute>
              <PassionManagementPage />
            </ProtectedRoute>
          }
        />
        <Route path="*" element={<Navigate to="/admin/login" replace />} />
      </Routes>
    </ThemeProvider>
  )
}
